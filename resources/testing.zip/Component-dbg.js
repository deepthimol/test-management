sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("testing.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);